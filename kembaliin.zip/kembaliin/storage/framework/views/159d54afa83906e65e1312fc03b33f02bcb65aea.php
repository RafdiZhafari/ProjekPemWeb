<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/tambahan.css">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <script src="http://maps.googleapis.com/maps/api/js"></script>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/home')); ?>";>
                <img src="/img/LogoKembali-IN.svg" alt="" width="150" height="50">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li style="padding-left: 20px; padding-top: 5px">
                        <h5>Welcome:) <strong><?php echo e(Auth::user()->name); ?></strong></h5>
                    </li>
                    <li class="nav-item" style="padding-left: 20px">
                        <a class="nav-link" aria-current="page" href="#"><strong>Profil & Pengaturan</strong></a>
                    </li>
                    <li class="nav-item" style="padding-left: 20px">
                        <a class="nav-link" aria-current="page" href="<?php echo e(url('/about')); ?>"><strong>Tentang Kami</strong></a>
                    </li>
                    <li style="padding-left: 20px">
                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-outline-dark">Logout</a>
                    </li>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-dark bg-light" type="submit">Search</button>
                </form>
                
            </div>
        </div>
    </nav>
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="js/bootstrap.bundle.js"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php echo $__env->yieldContent('container'); ?>;<?php /**PATH C:\xampp\htdocs\kembaliin\resources\views/layout/main.blade.php ENDPATH**/ ?>