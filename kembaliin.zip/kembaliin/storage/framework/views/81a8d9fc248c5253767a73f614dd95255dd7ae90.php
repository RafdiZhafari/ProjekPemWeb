<?php $__env->startSection('title', "Home"); ?>

<?php $__env->startSection('container'); ?>
    <script src="http://maps.googleapis.com/maps/api/js"></script>
    <div class="content">
        <script src="/js/Map.js"></script>
        <div id="googleMap" style="width:100%;height:620px;z-index:1;"></div>
        <button class="tLapor" onclick="window.location.href='penemuan.html';"></button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kembaliin\resources\views/home.blade.php ENDPATH**/ ?>