<?php $__env->startSection('title', "about"); ?>

<?php $__env->startSection('container'); ?>
<div class="content">
        <div class="container">
            <div class="row">
                <div class="col-3" style="background-color:#FDEFBE"><center>
                <h2 style="padding:13px;">About Us</h2>
                </center>
                <ul>
                    <li style='list-style-type: none;'>
                        <div class="daftar">
                            <img class="gambar" src="/img/amien.png">
                            <p><b>Amien Aziz</b><br>Main Programmer</p>
                        </div>
                    </li>
                    <li style='list-style-type: none;'>
                        <div class="daftar">
                            <img class="gambar" src="/img/daniel.png">
                            <p><b>Daniel Manurung</b><br>Side Programmer</p>
                        </div>
                    </li>
                    <li style='list-style-type: none;'>
                        <div class="daftar">
                            <img class="gambar" src="/img/rafdi.png">
                            <p><b>Rafdi Reyhan</b><br>Dokumenter, Quality Control</p>
                        </div>
                    </li>
                    <li style='list-style-type: none;'>
                        <div class="daftar">
                            <img class="gambar" src="/img/aris.png">
                            <p><b>Aris Dwi P.</b><br>Project Manager, Designer</p>
                        </div>
                    </li>
                </ul>
                </div>
                <div class="col">
                    <center>
                        <img src="/img/LogoKembali-IN.svg" alt="">
                        <hr style="height:2px;">
                    </center>
                    <p style="font-size:20px;">Kembali-IN merupakan aplikasi yang dapat mengintegrasikan komunitas untuk saling tolong menolong antar sesama manusia terutama dalam hal penemuan barang hilang. </p>
                    <p style="font-size:20px;">Aplikasi ini sangat mendorong kejujuran dan rasa tolong menolong sesama manusia, Pemilik barang bisa melakukan penelusuran area disekitarnya untuk melihat Pin yang menandakan temuan maupun tempat kehilangan barang disekitarnya. User juga bisa mencari melalui search box mengenai jenis barang yang ia hilangkan. Setelah menemukan postingan mengenai barang temuan. </p>
                    <p style="font-size:20px;">Pemilik barang dapat melakukan percakapan melalui pesan inbox untuk memastikan bahwa ia sang pemilik dengan mengatakan ciri-ciri barang hilang dan menentukan lokasi pengembalian barang dengan sang penemu atau bila kedua user tersebut sedang sibuk atau memiliki jarak rumah yang jauh, kami juga menyediakan fitur Kurir untuk mengirim barang.</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kembaliin\resources\views/about.blade.php ENDPATH**/ ?>