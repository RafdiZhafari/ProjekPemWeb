@extends('layout/main')

@section('title', "Home")

@section('container')
    <script src="http://maps.googleapis.com/maps/api/js"></script>
    <div class="content">
        <script src="/js/Map.js"></script>
        <div id="googleMap" style="width:100%;height:620px;z-index:1;"></div>
        <button class="tLapor" onclick="window.location.href='penemuan.html';"></button>
    </div>
@endsection